﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LanceScript : MyUnit {

    public GameObject HighL;
    void Start()
    {
        HighL = GameObject.Find("Highlighted");
    }
    void MarkAsSelected()
    {
        HighL.SetActive(true);
    }

    void UnMark()
    {
        HighL.SetActive(false);
    }
}
