public class CellGridStateGameOver : CellGridState
{
    public CellGridStateGameOver(CellGrid cellGrid) : base(cellGrid)
    {
    }

    public override void OnStateEnter()
    {
    }
}