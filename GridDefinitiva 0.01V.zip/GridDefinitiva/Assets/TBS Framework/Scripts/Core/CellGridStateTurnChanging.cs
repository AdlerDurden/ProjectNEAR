﻿class CellGridStateTurnChanging : CellGridState
{
    public CellGridStateTurnChanging(CellGrid cellGrid) : base(cellGrid)
    {
    }
}

